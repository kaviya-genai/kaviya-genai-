# ============================================================
# chatbot.py
# Author: Kaviya Dharshini | Generative AI Developer
# Description: Main RAG chatbot interface
# ============================================================

from retriever import load_vectorstore, retrieve_documents, format_context


def build_prompt(query: str, context: str) -> str:
    """Build a prompt with retrieved context for the LLM."""
    prompt = f"""You are a helpful AI assistant. Use the context below to answer the question accurately.
If the answer is not in the context, say "I don't have enough information to answer this."

Context:
{context}

Question: {query}

Answer:"""
    return prompt


def chat(query: str, vectorstore):
    """Main chat function: retrieve context and generate answer."""
    # Step 1: Retrieve relevant documents
    docs = retrieve_documents(query, vectorstore, top_k=3)

    # Step 2: Format context
    context = format_context(docs)

    # Step 3: Build prompt
    prompt = build_prompt(query, context)

    # Step 4: Return prompt (connect your LLM API here)
    # Example: response = call_llm_api(prompt)
    print("\n=== Generated Prompt ===")
    print(prompt[:500] + "...")
    print("========================\n")
    print("Connect your LLM API (AWS Bedrock / OpenAI) to generate final answer.")
    return prompt


def run_chatbot():
    """Interactive chatbot loop."""
    print("=" * 50)
    print("  RAG PDF Chatbot - by Kaviya Dharshini")
    print("  Generative AI Developer")
    print("=" * 50)

    # Load vectorstore
    vectorstore = load_vectorstore()

    print("\nChatbot ready! Type 'exit' to quit.\n")

    while True:
        query = input("You: ").strip()
        if query.lower() in ["exit", "quit", "bye"]:
            print("Goodbye!")
            break
        if not query:
            continue
        chat(query, vectorstore)


if __name__ == "__main__":
    run_chatbot()
