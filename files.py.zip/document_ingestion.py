# ============================================================
# document_ingestion.py
# Author: Kaviya Dharshini | Generative AI Developer
# Description: PDF parsing, chunking and vector indexing
# ============================================================

import os
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.vectorstores import FAISS


def load_pdf(file_path: str):
    """Load a PDF file and return documents."""
    print(f"Loading PDF: {file_path}")
    loader = PyPDFLoader(file_path)
    documents = loader.load()
    print(f"Loaded {len(documents)} pages.")
    return documents


def chunk_documents(documents, chunk_size=512, chunk_overlap=50):
    """Split documents into smaller chunks for better retrieval."""
    print(f"Chunking documents (size={chunk_size}, overlap={chunk_overlap})...")
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap
    )
    chunks = splitter.split_documents(documents)
    print(f"Created {len(chunks)} chunks.")
    return chunks


def create_vectorstore(chunks, save_path="vectorstore/"):
    """Generate embeddings and store in FAISS vector database."""
    print("Generating embeddings using SentenceTransformers...")
    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    os.makedirs(save_path, exist_ok=True)
    vectorstore.save_local(save_path)
    print(f"Vectorstore saved to: {save_path}")
    return vectorstore


def ingest_pdf(file_path: str, save_path="vectorstore/"):
    """Full pipeline: Load PDF → Chunk → Embed → Save."""
    documents = load_pdf(file_path)
    chunks = chunk_documents(documents)
    vectorstore = create_vectorstore(chunks, save_path)
    print("Document ingestion complete!")
    return vectorstore


if __name__ == "__main__":
    # Example usage
    pdf_path = "sample.pdf"  # Replace with your PDF path
    ingest_pdf(pdf_path)
