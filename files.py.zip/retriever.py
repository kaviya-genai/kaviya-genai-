# ============================================================
# retriever.py
# Author: Kaviya Dharshini | Generative AI Developer
# Description: Semantic search and document retrieval using FAISS
# ============================================================

from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.vectorstores import FAISS


def load_vectorstore(save_path="vectorstore/"):
    """Load existing FAISS vectorstore from disk."""
    print("Loading vectorstore...")
    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = FAISS.load_local(save_path, embeddings)
    print("Vectorstore loaded successfully!")
    return vectorstore


def retrieve_documents(query: str, vectorstore, top_k=3):
    """Retrieve top-k most relevant document chunks for a query."""
    print(f"Searching for: '{query}'")
    retriever = vectorstore.as_retriever(search_kwargs={"k": top_k})
    docs = retriever.get_relevant_documents(query)
    print(f"Retrieved {len(docs)} relevant chunks.")
    return docs


def format_context(docs):
    """Format retrieved documents into a single context string."""
    context = "\n\n".join([doc.page_content for doc in docs])
    return context


if __name__ == "__main__":
    # Example usage
    vectorstore = load_vectorstore()
    query = "What are the healthcare protocols?"
    docs = retrieve_documents(query, vectorstore)
    for i, doc in enumerate(docs):
        print(f"\n--- Chunk {i+1} ---")
        print(doc.page_content[:300])
